//
//  PageAlbumTableView.swift
//  hw9
//
//  Created by Alex Hong on 4/25/17.
//  Copyright © 2017 Alex Hong. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import SwiftSpinner

var PageAlbumJSon = Array<JSON>()


class PageAlbumTableView: UIViewController,UITableViewDelegate,UITableViewDataSource {

    
    @IBOutlet weak var pageAlbumTable: UITableView!
    
    override func viewDidLoad() {
        SwiftSpinner.show(duration: 4.0, title: "loading data...")
        super.viewDidLoad()
        
        pageAlbumTable.delegate=self
        pageAlbumTable.dataSource=self
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        if(pageId==""){
            return
        }
        print("http://cs-server.usc.edu:18487/index1.php?id=\(pageId)")
        Alamofire.request("http://cs-server.usc.edu:18487/index1.php?id=\(pageId)", method: .get).validate().responseJSON{
            response in
            switch response.result{
            case .success(let value):
                let json = JSON(value)
                let obj = json["albums"]["data"]
                for i in 0..<obj.count{
                    PageAlbumJSon.append(obj[i])
                }
                self.pageAlbumTable.reloadData()
            case .failure(let error):
                print("Request failed with error: \(error)")
            }
        }

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if PageAlbumJSon.count>0{
            return PageAlbumJSon.count
        }
        return 1
    }

     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "pageAlbumCell", for: indexPath) as! AlbumTableCell
        if PageAlbumJSon.count == 0{
            print("last cell")
            cell.albumNameCell.text="No data found"
            return cell
        }
//        print(PageAlbumJSon.count)
//        print(PageAlbumJSon[indexPath.row]["photos"]["data"]["picture"][0])
        
        print("hwl"+PageAlbumJSon[indexPath.row]["name"].string!)
               if let albumNameCell = PageAlbumJSon[indexPath.row]["name"].string{
                
                    print("rel11111111111")
                            cell.albumNameCell.text = albumNameCell
                }
        
//        if  albumPicCell1 = PageAlbumJSon[indexPath.row]["photos"]["data"]["picture"][1]{
//                cell.albumPicCell1.image = UIImage[Data]
//        }
        
        print( PageAlbumJSon[indexPath.row]["photos"]["data"][1] )
        print( PageAlbumJSon[indexPath.row]["photos"]["data"][1]["picture"])
         print( PageAlbumJSon[indexPath.row]["photos"]["data"][0]["picture"])
        
        if let albumPicCell1 = PageAlbumJSon[indexPath.row]["photos"]["data"][0]["picture"].string{
            if let url = NSURL(string: albumPicCell1){
                if let imgData = NSData(contentsOf: url as URL){
                    cell.albumPicCell1.image=UIImage(data: imgData as Data)
                }
            }
            
        }
        
        if let albumPicCell1 = PageAlbumJSon[indexPath.row]["photos"]["data"][1]["picture"].string{
            if let url = NSURL(string: albumPicCell1){
                if let imgData = NSData(contentsOf: url as URL){
                    cell.albumPicCell2.image=UIImage(data: imgData as Data)
                }
            }
            
        }
        
        
        
        
        
    SwiftSpinner.hide()
    return cell

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    }
}
