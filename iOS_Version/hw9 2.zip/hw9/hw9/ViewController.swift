//
//  ViewController.swift
//  hw9
//
//  Created by Alex Hong on 4/23/17.
//  Copyright © 2017 Alex Hong. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
var key=""
class ViewController: UIViewController{
    
    
    var searchURL = "http://cs-server.usc.edu:18487/index1.php/?q=usc&type=user&fields=id,name,picture.width(700).height(700)&limit=10"
    @IBOutlet weak var Menu: UIBarButtonItem!
    
    @IBOutlet weak var TextField: UITextField!
    
    @IBAction func SearchBtn(_ sender: UIButton) {
        print("\(TextField.text!)")
        downloadJSon()
    }
    @IBAction func ClearBtn(_ sender: UIButton) {
            TextField.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if revealViewController() != nil {
        Menu.target = self.revealViewController()
        Menu.action = #selector(SWRevealViewController.revealToggle(_:))
            
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
    }
}
    
   


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func downloadJSon(){
        
        let keywords = TextField.text
        key=keywords ?? ""
        
    }
    
    


}

